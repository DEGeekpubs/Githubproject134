<?php

$configVars = array(
    'database_dsn'  => 'mysql:dbname=swe2;host=localhost',
    'database_user' => 'root',
    'database_pass' => null,
);

return $configVars;
